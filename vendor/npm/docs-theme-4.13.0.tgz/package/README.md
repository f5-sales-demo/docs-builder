# XC Docs Theme

🌐 English |
[日本語](https://f5-sales-demo.github.io/docs-theme/ja/) |
[한국어](https://f5-sales-demo.github.io/docs-theme/ko/) |
[简体中文](https://f5-sales-demo.github.io/docs-theme/zh-cn/) |
[繁體中文](https://f5-sales-demo.github.io/docs-theme/zh-tw/) |
[Español](https://f5-sales-demo.github.io/docs-theme/es/) |
[Português](https://f5-sales-demo.github.io/docs-theme/pt-br/) |
[Français](https://f5-sales-demo.github.io/docs-theme/fr/) |
[Deutsch](https://f5-sales-demo.github.io/docs-theme/de/) |
[Italiano](https://f5-sales-demo.github.io/docs-theme/it/) |
[العربية](https://f5-sales-demo.github.io/docs-theme/ar/) |
[हिन्दी](https://f5-sales-demo.github.io/docs-theme/hi/) |
[ไทย](https://f5-sales-demo.github.io/docs-theme/th/)

[![GitHub Pages Deploy](https://github.com/f5-sales-demo/docs-theme/actions/workflows/github-pages-deploy.yml/badge.svg)](https://github.com/f5-sales-demo/docs-theme/actions/workflows/github-pages-deploy.yml)
[![Repository Settings](https://github.com/f5-sales-demo/docs-theme/actions/workflows/enforce-repo-settings.yml/badge.svg)](https://github.com/f5-sales-demo/docs-theme/actions/workflows/enforce-repo-settings.yml)
[![Release](https://github.com/f5-sales-demo/docs-theme/actions/workflows/release.yml/badge.svg)](https://github.com/f5-sales-demo/docs-theme/actions/workflows/release.yml)
[![License](https://img.shields.io/github/license/f5-sales-demo/docs-theme)](LICENSE)

Shared branding and styling for F5 Distributed Cloud documentation sites

## Documentation

Full documentation is available at __[https://f5-sales-demo.github.io/docs-theme/](https://f5-sales-demo.github.io/docs-theme/)__.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for workflow rules,
branch naming, and CI requirements.

## License

See [LICENSE](LICENSE).

## Canadian flag artwork

`assets/canada-flag.svg` is the unmodified Canadian 4:3 flag from
[flag-icons v7.5.0](https://github.com/lipis/flag-icons/tree/v7.5.0).
`assets/canada-favicon.svg` centers the same flag on a square white canvas.
Copyright and MIT license terms are retained in
[assets/flag-icons-LICENSE.txt](assets/flag-icons-LICENSE.txt).
The Canada publication profile preserves English routing and selects its local flag favicon.
Callers can override the optional `favicon` field in `createF5xcDocsConfig`.
